import 'package:flutter/material.dart';
import 'walkthrough.dart';
import 'signup.dart';
import 'login_screen.dart';
import 'welcome.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/walkthrough',
      routes: {
        '/walkthrough': (context) => WalkThrough(),
        '/signup': (context) => SignUpScreen(),
        '/login': (context) => LoginScreen(),
        '/welcome': (context) => WelcomeScreen(),
      },
    );
  }
}
